#-*- coding: utf-8 -*-
import os
import optparse

class SubCommandError(Exception):
    pass

def cms(path):
    pass

def ticketing(path):
    path = os.path.abspath(path)
    if path.endswith('.xz'):
        os.system('unxz "{0}"'.format(path))
    path = path.strip('.xz')
    if not os.path.isfile(path):
        raise SubCommandError()
    
    os.system('''
mysql -u root -p ticketing << EOF
drop database ticketing;
create database ticketing default character set utf8;
EOF''')

    os.system('''
mysql -u ticketing -p ticketing < {snapshot};
mysql -u ticketing -p ticketing << EOF
update Service set redirect_uri = "http://localhost:6543/auth/oauth_callback";
EOF'''.format(snapshot=path))
    return 0

def main(argv):
    parser = optparse.OptionParser()
    opts, args = parser.parse_args(argv)
    
    try:
        target = args[0]
        path = args[1]
    except IndexError as err:
        parser.error(err)

    return ticketing(path)
    
