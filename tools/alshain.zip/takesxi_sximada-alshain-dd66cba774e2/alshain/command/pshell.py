#-*- coding: utf-8 -*-
import os

def main(argv):
    os.system('alshain cmd altair_pshell_ticketing')
    
