#! /usr/bin/env python
#-*- coding: utf-8 -*-
import sys
import optparse

import jumon

def main():
    jumon.entry('alshain.command')

    
