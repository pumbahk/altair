#-*- coding: utf-8 -*-
import urllib2
import cookielib

def main(args):
    cj = cookielib.CookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    res = opener.open('http://backend.stg2.rt.ticketstar.jp')
    print res

