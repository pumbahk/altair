#-*- coding: utf-8 -*-
"""Alshain is the beta of Aquila.

Alshain is a yello-hued star of magnitude 3.7, 45 light-years from Earth. Its Name
comes from the Arabic phrase "shahin-i tarazu", meaning "the balance"; this name
referred to Altair, Alshain, and Tarazed.

by wikipedia
"""

__all__ = ['commandline']

    
